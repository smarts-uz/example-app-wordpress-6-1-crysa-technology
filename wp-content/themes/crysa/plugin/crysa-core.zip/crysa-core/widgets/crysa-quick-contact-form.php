<?php
	/**
	* Elementor Quick Contact Form Widget.
	*
	* Elementor widget that inserts an embbedable content into the page, from any given URL.
	*
	* @since 1.0.0
	*/
class Elementor_Quick_Contact_Form_Widget extends \Elementor\Widget_Base {

	/**
	* Get widget name.
	*
	* Retrieve Quick Contact Form widget name.
	*
	* @since 1.0.0
	* @access public
	*
	* @return string Widget name.
	*/
	public function get_name() {
		return 'quick_contact_form';
	}

	/**
	* Get widget title.
	*
	* Retrieve Quick Contact Form widget title.
	*
	* @since 1.0.0
	* @access public
	*
	* @return string Widget title.
	*/
	public function get_title() {
		return esc_html__( 'Quick Contact Form', 'crysa-core' );
	}

	/**
	* Get widget icon.
	*
	* Retrieve Quick Contact Form widget icon.
	*
	* @since 1.0.0
	* @access public
	*
	* @return string Widget icon.
	*/
	public function get_icon() {
		return 'fa fa-bars';
	}

	/**
	* Get widget categories.
	*
	* Retrieve the list of categories the Quick Contact Form widget belongs to.
	*
	* @since 1.0.0
	* @access public
	*
	* @return array Widget categories.
	*/
	public function get_categories() {
		return [ 'crysa-elements' ];
	}
	
	// Add The Input For User
	protected function register_controls(){

		$this->start_controls_section(
			'quick_contact_form_content',
			[
				'label'		=> esc_html__( 'Set quick Contact Form Content','crysa-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'contact_shortcode',
			[
				'label' 		=> esc_html__( 'Contact Form Shortcode', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'rows' 			=> 3,
				'placeholder' 	=> esc_html__( 'Put your shortcode Here', 'crysa-core' ),
			]

		);

		$this->add_control(
			'quick_contact_form_divider',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'quick_contact_title', [
				'label' 		=> esc_html__( 'Title', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'label_block' 	=> true,
				'rows' 			=> 3,
			]
		);

		$this->add_control(
			'quick_contact_phone', [
				'label' 		=> esc_html__( 'Phone', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'label_block' 	=> true,
				'rows' 			=> 3,
			]
		);

		$this->add_control(
			'icon_style',
			[
				'label' 	=> esc_html__( 'Icon Style', 'crysa-core' ),
				'type' 		=> \Elementor\Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  	=> esc_html__( 'Flaticon', 'crysa-core' ),
					'3' 	=> esc_html__( 'Icon Image', 'crysa-core' ),
					'2'  	=> esc_html__( 'Custom Icon', 'crysa-core' ),
				],
			]
		);

		$this->add_control(
			'flat_icon',
			[
                'label'      => esc_html__('Icon One', 'cleanu-core'),
                'type'       => \Elementor\Controls_Manager::ICON,
                'options'    => crysa_flaticons(),
                'include'    => crysa_include_flaticons(),
                'condition' => [
                    'icon_style' => '1'
                ]
            ]
		);

		$this->add_control(
			'custom_icon', [
				'label' 		=> esc_html__( 'Custom Icon', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'label_block' 	=> true,
				'condition' => [
                    'icon_style' => '2'
                ]
			]
		);


		$this->add_control(
			'icon_image',
			[
				'label'			=> esc_html__( 'Add Image Icon','crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::MEDIA,
				'condition' => [
                    'icon_style' => '3'
                ]
			]
		);
		
		$this->end_controls_section();
	}

	// Output For User
	protected function render(){
	$crysa_quick_contact_form = $this->get_settings_for_display();
	?>

    <!-- Start Quick Contact Form Area 
    ============================================= -->
    <?php echo do_shortcode($crysa_quick_contact_form['contact_shortcode']);?>
    <ul class="contact-list">
        <li>
            <div class="icon">
                <?php if(!empty($crysa_quick_contact_form['flat_icon'])):?>
                    <i class="<?php echo esc_attr($crysa_quick_contact_form['flat_icon']); ?>"></i>
                <?php endif;?>
                <?php if(!empty($crysa_quick_contact_form['icon_image'])):?>
                    <img src="<?php echo esc_url($crysa_quick_contact_form['icon_image']['url']); ?>">
                <?php endif;?>
                <?php 
                if(!empty($crysa_quick_contact_form['custom_icon'])):?>
                    <i class="<?php echo esc_attr($crysa_quick_contact_form['custom_icon']); ?>"></i>
                <?php endif;?>
            </div>
            <div class="info">
                <h5><?php echo esc_html($crysa_quick_contact_form['quick_contact_title']);?></h5>
                <a href="tel:<?php echo esc_attr($crysa_quick_contact_form['quick_contact_phone']);?>"><?php echo htmlspecialchars_decode(esc_html($crysa_quick_contact_form['quick_contact_phone']));?></a>
            </div>
        </li>
    </ul>
    <!-- End Quick Contact Form  Area -->
	<?php
	}
}