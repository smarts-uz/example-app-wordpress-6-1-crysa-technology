<?php
	/**
	* Elementor Achivement Widget.
	*
	* Elementor widget that inserts an embbedable content into the page, from any given URL.
	*
	* @since 1.0.0
	*/
class Elementor_Achivement_Widget extends \Elementor\Widget_Base {

	/**
	* Get widget name.
	*
	* Retrieve Achivement widget name.
	*
	* @since 1.0.0
	* @access public
	*
	* @return string Widget name.
	*/
	public function get_name() {
		return 'crysa_achivemnt_one';
	}

	/**
	* Get widget title.
	*
	* Retrieve Achivement widget title.
	*
	* @since 1.0.0
	* @access public 
	*
	* @return string Widget title.
	*/
	public function get_title() {
		return esc_html__( 'Achivement Style One', 'crysa-core' );
	}

	/**
	* Get widget icon.
	*
	* Retrieve Achivement widget icon.
	*
	* @since 1.0.0
	* @access public
	*
	* @return string Widget icon.
	*/
	public function get_icon() {
		return 'fa fa-bars';
	}

	/**
	* Get widget categories.
	*
	* Retrieve the list of categories the Achivement widget belongs to.
	*
	* @since 1.0.0
	* @access public
	*
	* @return array Widget categories.
	*/
	public function get_categories() {
		return [ 'crysa-elements'];
	}

	public function get_script_depends() {
        return array('main');
    }

	// Add The Input For User
	protected function register_controls(){
		
		

		$this->start_controls_section(
			'Achivements_content',
			[
				'label'		=> esc_html__( 'Set Achivement Content','crysa-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'title', [
				'label' 		=> esc_html__( 'Title', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'label_block' 	=> true,
			]
		);
		
		$this->add_control(
			'content', [
				'label' 		=> esc_html__( 'Content', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'image',
			[
				'label'			=> esc_html__( 'Add Image','crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'funfactor', [
				'label' 		=> esc_html__( 'Funfactor Number', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'label_block' 	=> true,
			]
		);
		

		$this->end_controls_section();

		$this->start_controls_section(
			'achivement_style',
			[
				'label'			=> esc_html__( 'Style','crysa-core' ),
				'tab' 			=> \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$this->end_controls_section();

	}

	// Output For User
	protected function render(){
	$crysa_achivements_output = $this->get_settings_for_display();

	?>
	<!-- Start Achivements Style One
    ============================================= -->
    <div class="achivement-style-one text-light">
        <div class="item" style="background-image: url(<?php echo esc_url($crysa_achivements_output['image']['url']);?>);">
            <div class="progressbar">
                <div class="circle" data-percent="<?php echo esc_attr($crysa_achivements_output['funfactor']);?>">
                    <strong></strong>
                </div>
            </div>
            <div class="content">
                <h4><?php echo esc_html($crysa_achivements_output['title']);?></h4>
                <p><?php echo esc_html($crysa_achivements_output['content']);?></p>
            </div>
        </div>
    </div>
    <!-- End Achivements Style One -->
	<?php 
	}
}