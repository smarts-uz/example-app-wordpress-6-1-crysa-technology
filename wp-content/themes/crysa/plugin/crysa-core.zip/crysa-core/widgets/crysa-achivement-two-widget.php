<?php
	/**
	* Elementor Achivement Style Two Widget.
	*
	* Elementor widget that inserts an embbedable content into the page, from any given URL.
	*
	* @since 1.0.0
	*/
class Elementor_Achivement_Two_Widget extends \Elementor\Widget_Base {

	/**
	* Get widget name.
	*
	* Retrieve Achivement Style Two widget name.
	*
	* @since 1.0.0
	* @access public
	*
	* @return string Widget name.
	*/
	public function get_name() {
		return 'crysa_achivemnt_two';
	}

	/**
	* Get widget title.
	*
	* Retrieve Achivement widget title.
	*
	* @since 1.0.0
	* @access public 
	*
	* @return string Widget title.
	*/
	public function get_title() {
		return esc_html__( 'Achivement Style Two', 'crysa-core' );
	}

	/**
	* Get widget icon.
	*
	* Retrieve Achivement widget icon.
	*
	* @since 1.0.0
	* @access public
	*
	* @return string Widget icon.
	*/
	public function get_icon() {
		return 'fa fa-bars';
	}

	/**
	* Get widget categories.
	*
	* Retrieve the list of categories the Achivement widget belongs to.
	*
	* @since 1.0.0
	* @access public
	*
	* @return array Widget categories.
	*/
	public function get_categories() {
		return [ 'crysa-elements'];
	}

	public function get_script_depends() {
        return array('main');
    }

	// Add The Input For User
	protected function register_controls(){
		
		

		$this->start_controls_section(
			'achivement_style_two_content',
			[
				'label'		=> esc_html__( 'Set Achivement Content','crysa-core' ),
				'tab'		=> \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'title', [
				'label' 		=> esc_html__( 'Title', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'label_block' 	=> true,
			]
		);
		
		$this->add_control(
			'content', [
				'label' 		=> esc_html__( 'Content', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'image',
			[
				'label'			=> esc_html__( 'Add Image','crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'funfactor', [
				'label' 		=> esc_html__( 'Funfactor Number', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'label_block' 	=> true,
			]
		);
		$this->add_control(
			'operator', [
				'label' 		=> esc_html__( 'Operator', 'crysa-core' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'label_block' 	=> true,
			]
		);
		

		$this->end_controls_section();

		$this->start_controls_section(
			'achivement_two_style',
			[
				'label'			=> esc_html__( 'Style','crysa-core' ),
				'tab' 			=> \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$this->end_controls_section();

	}

	// Output For User
	protected function render(){
	$crysa_achivement_two_output = $this->get_settings_for_display();

	?>
	<!-- Start Achivements Style Two
    ============================================= -->
   	<div class="achivement-style-one">
        <div class="item bg-gradient text-light">
            <div class="content">
                <div class="achivement">
                    <div class="fun-fact">
                        <div class="counter">
                            <div class="timer" data-to="<?php echo esc_attr($crysa_achivement_two_output['funfactor']);?>" data-speed="1000"><?php echo esc_html($crysa_achivement_two_output['funfactor']);?></div><div class="operator"><?php echo esc_html($crysa_achivement_two_output['operator']);?></div>
                        </div>
                        <h4><?php echo esc_html($crysa_achivement_two_output['title']);?></h4>
                    </div>
                </div>
                <p><?php echo esc_html($crysa_achivement_two_output['content']);?></p>
            </div>
        </div>
    </div>
    <!-- End Achivements Style Two -->
	<?php 
	}
}